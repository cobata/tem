public enum ErrorType
{
	正常,
	PIN碼錯誤,
	已被鎖卡,
	未接上讀卡機,
	未插入卡片,
	非指定的卡片類型,
	憑證錯誤,
	非預期錯誤
}

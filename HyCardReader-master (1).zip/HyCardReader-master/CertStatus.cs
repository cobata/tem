public enum CertStatus
{
	未驗證,
	驗證通過,
	驗證不通過
}

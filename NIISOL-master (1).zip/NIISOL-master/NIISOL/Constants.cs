public class Constants
{
	public const string VERSION = "1.0.0.0";

	public static string LogFileName = "C:\\NIISOL\\OffErrorLog.txt";
}

using System;
using System.Collections.Generic;
using System.Text;

namespace T00SharedLibraryDotNet20
{
	public enum CommandOperationType
	{
		ExecuteNonQuery,
		ExecuteReader,
		ExecuteScalar,
		ExecuteReaderReturnDataTable
	}

}
